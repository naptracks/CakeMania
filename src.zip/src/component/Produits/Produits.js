import React, { Component } from 'react';

class Produits extends Component {
    constructor(props){
        super(props)
        this.state={
          descriptif : 
     }
    }

    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default Produits;