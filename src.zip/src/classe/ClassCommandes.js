class ClassCommandes {
    idCommande; //timestemp
    
    produits;
    nbrProduit;
    produitPrix;

    totalPrix;
    totalNbrProduit;

    dateCommande;
    dateRetrait;
}

export default ClassCommandes;