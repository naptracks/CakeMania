class ClassProduit {
    id;
    name;
    description;
    price;
    image;
    isRecomanded;
    size;
    base;
}

export default ClassProduit;