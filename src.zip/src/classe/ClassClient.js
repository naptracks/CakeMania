class ClassClient {
    id;
    lastName;
    firstName;
    email;
    adressePostale;
    codePostal;
    ville;
    tel;
    paiement;
    commande;
}

export default ClassClient;